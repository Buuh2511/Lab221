# 950-LOC-LAB221
How to achieve 950 LOC in LAB221 in 72 hours.
